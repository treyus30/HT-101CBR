/*
 * Erstellt am: 05.12.2003
 * Autor:       Maximilian Thiele
 * 
 */


import gui.CharEditor;
import gui.MainWindow;

import javax.swing.*;

public class FontCreator extends JFrame {
	private CharEditor ce;
	private JTextArea code;
	
	public static void main(String args[]) {
		new MainWindow();
	}
}