var searchData=
[
  ['init_0',['init',['../struct_ticker_state.html#a26c1dff76fd6f2bafa4d75fe87e224f5',1,'TickerState']]],
  ['initcmds_1',['initcmds',['../struct_dev_type.html#adb1a2fe45c58f002fe4e535f4dc4c57e',1,'DevType']]],
  ['initsize_2',['initSize',['../struct_dev_type.html#a0c7a0aae17eedda9252d9e777605a245',1,'DevType']]]
];
